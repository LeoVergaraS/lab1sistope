# lab1sistope
Este proyecto tiene presente el laboratorio número 1 de Sistemas Operativos, donde se abordan las funciones fork(), pipe(), entre otras, en C.
